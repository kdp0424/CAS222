<?php

/*
File Name: functions.php
Date: 2/27/2018
Programmer: Kelli Pando
*/

// Functions

include_once "includes/functions.php";

// end functions

// form above is wonky?


<form id="form1" name="form1" method="post" action="registration_add_action.php">

<table class="shade addTable">

<tr class="addRecord">
<td class="col1">Username: </td>

<?php

// CALL FUNCTION TO CREATE DYNAMIC SELECT BOX

$field_name = "name";

$table_name = "registration";

$list = select_box($field_name, $table_name, $result);

echo "<td class='col2'>" . $list . "</td>";

?>

</tr>

<tr class="addRecord">
<td class="col1">Comment: </td><td class="col2"><textarea name="comment" cols="50" rows="3" id="comment"></textarea></td>
</tr>

<tr class="addRecord">
<td class="col1">&nbsp;</td><td class="col2"><input type="submit" name="Submit" value="Submit" /></td>
</tr>

</table>

</form>

<!-- This JavaScript puts the cursor in the first element on the form -->
<script>document.getElementById('form1').elements[0].focus();</script>




?>